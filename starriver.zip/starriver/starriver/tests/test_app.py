# -*- coding: utf-8 -*-
"""经络星河后端路由测试。"""

from app import create_app


def client():
    app = create_app({"TESTING": True})
    return app.test_client()


def test_jingluo_redirects_to_easy_game():
    response = client().get("/jingluo")
    assert response.status_code == 302
    assert "/meridian-match?difficulty=easy" in response.location


def test_explicit_star_view_does_not_redirect():
    response = client().get("/jingluo?view=stars")
    assert response.status_code == 200
    assert "十四经络星路" in response.get_data(as_text=True)


def test_difficulty_falls_back_to_easy():
    response = client().get("/meridian-match?difficulty=unknown")
    assert response.status_code == 200
    assert "window.GAME_DIFFICULTY=\"easy\"" in response.get_data(as_text=True)


def test_knowledge_has_fourteen_meridians():
    response = client().get("/api/knowledge")
    assert response.status_code == 200
    assert len(response.get_json()) == 14


def test_record_validation():
    response = client().post("/api/records", json={"difficulty": "easy"})
    assert response.status_code == 400


def test_animated_guide_assets_are_served_as_images():
    test_client = client()
    assert test_client.get("/static/images/guide-mascot.webp").content_type == "image/webp"
    assert test_client.get("/static/images/guide-mascot.gif").content_type == "image/gif"

