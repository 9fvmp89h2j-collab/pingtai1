# -*- coding: utf-8 -*-
"""Clean a white-backed animated GIF and export looping web assets.

Only edge-connected near-white pixels are removed, so enclosed white details on
the character remain intact. All frames share one crop box to prevent jitter.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageSequence


THEME_BACKGROUND = (246, 241, 231, 255)


def clean_frame(frame: Image.Image, threshold: int) -> Image.Image:
    cleaned = frame.convert("RGBA")
    # The source background is connected around the character. Flood filling
    # from every corner removes its antialiased white fringe without erasing
    # enclosed light costume and hair details.
    for corner in ((0, 0), (cleaned.width - 1, 0), (0, cleaned.height - 1),
                   (cleaned.width - 1, cleaned.height - 1)):
        ImageDraw.floodfill(cleaned, corner, (255, 255, 255, 0), thresh=threshold)
    return cleaned


def union_bbox(frames: list[Image.Image], padding: int) -> tuple[int, int, int, int]:
    boxes = [frame.getchannel("A").getbbox() for frame in frames]
    boxes = [box for box in boxes if box]
    left = max(0, min(box[0] for box in boxes) - padding)
    top = max(0, min(box[1] for box in boxes) - padding)
    right = min(frames[0].width, max(box[2] for box in boxes) + padding)
    bottom = min(frames[0].height, max(box[3] for box in boxes) + padding)
    return left, top, right, bottom


def process(source: Path, webp_output: Path, gif_output: Path, threshold: int) -> None:
    with Image.open(source) as image:
        durations: list[int] = []
        frames: list[Image.Image] = []
        for frame in ImageSequence.Iterator(image):
            durations.append(frame.info.get("duration", image.info.get("duration", 50)))
            frames.append(clean_frame(frame, threshold))

    crop_box = union_bbox(frames, padding=18)
    frames = [frame.crop(crop_box) for frame in frames]

    webp_output.parent.mkdir(parents=True, exist_ok=True)
    frames[0].save(
        webp_output,
        save_all=True,
        append_images=frames[1:],
        duration=durations,
        loop=0,
        lossless=True,
        method=6,
    )

    themed_frames: list[Image.Image] = []
    for frame in frames:
        background = Image.new("RGBA", frame.size, THEME_BACKGROUND)
        background.alpha_composite(frame)
        themed_frames.append(background.convert("RGB"))
    themed_frames[0].save(
        gif_output,
        save_all=True,
        append_images=themed_frames[1:],
        duration=durations,
        loop=0,
        disposal=2,
        optimize=True,
    )

    print(f"frames={len(frames)} size={frames[0].size} loop=forever")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("webp_output", type=Path)
    parser.add_argument("gif_output", type=Path)
    parser.add_argument("--threshold", type=int, default=34)
    args = parser.parse_args()
    process(args.source, args.webp_output, args.gif_output, args.threshold)


if __name__ == "__main__":
    main()

