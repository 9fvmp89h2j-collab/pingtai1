(() => {
  'use strict';
  const settings = {
    easy: { count: 6, seconds: 180, hints: 3, multiplier: 1, label: '初级 · 星光识经' },
    normal: { count: 10, seconds: 180, hints: 2, multiplier: 1.2, label: '中级 · 文字辨脉' },
    hard: { count: 14, seconds: 240, hints: 0, shuffles: 1, multiplier: 1.5, label: '高级 · 星河默记' }
  };
  const milestones = [50, 100, 200, 350, 500, 750, 1000];
  const boardEl = document.querySelector('#board');
  let knowledge = [], pool = [], board = [], difficulty = window.GAME_DIFFICULTY || 'easy';
  let selected = null, score = 0, combo = 0, remaining = 0, timerId = null, startedAt = 0;
  let collectedStars = 0, depositedStars = 0;
  let hintsLeft = 0, shufflesLeft = 0, mistakes = [], completed = new Set(), busy = false;
  let pendingDifficulty = null;
  let movesMade = 0;

  let ROWS = 10, COLS = 10;
  let boardShape = '10x10';
  let boardValid = [];

  const bgm = new Audio('/static/audio/bgm.mp3');
  bgm.loop = true;
  bgm.volume = 0.4;
  let isSoundOn = true;

  const $ = s => document.querySelector(s);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  const index = (r, c) => r * COLS + c;
  const coords = i => [Math.floor(i / COLS), i % COLS];

  const adjacent = (a, b) => { const [ar, ac] = coords(a), [br, bc] = coords(b); return Math.abs(ar-br)+Math.abs(ac-bc) === 1; };
  const randomTile = () => { const m = pool[Math.floor(Math.random()*pool.length)]; return { meridian:m.id, point:m.acupoints[Math.floor(Math.random()*m.acupoints.length)], serial:Math.ceil(Math.random()*99) }; };
  const meridian = id => knowledge.find(m => m.id === id);

  let idleTimer = null;
  const idleTips = [
    "找不到可以消除的星吗？可以点击‘帮我找一找’哦！",
    "如果卡住了，试试‘摇一摇星盘’重新排列吧。",
    "小提示：初级棋盘里，四个连成一线会生成整行/列消除星！",
    "初级棋盘里，T形或L形消除能生成加5秒的时间星哦！",
    "点一下发光的特殊星星，就能触发它的神奇魔力！",
    "相邻的星星才能交换，斜着是不行的哦。",
    "你可以把我拖拽到屏幕的其他地方，别让我挡住棋盘哦！"
  ];
  const successTips = [
    "太棒了！继续保持连击！",
    "星力正在汇聚！",
    "太厉害了，这片星海都亮起来了！",
    "有没有记住刚刚消除的穴位呀？"
  ];

  function resetIdleTimer() {
    clearTimeout(idleTimer);
    if (!timerId) return;
    idleTimer = setTimeout(() => {
      guideSay(idleTips[Math.floor(Math.random() * idleTips.length)]);
    }, 8000);
  }

  function setupBoardShape(shape) {
    boardShape = shape;
    if (shape === '5x5') { ROWS = 5; COLS = 5; }
    else if (shape === '6x6') { ROWS = 6; COLS = 6; }
    else if (shape === '7x7') { ROWS = 7; COLS = 7; }
    else if (shape === '8x8') { ROWS = 8; COLS = 8; }
    else if (shape === 'cross') { ROWS = 9; COLS = 9; }
    else if (shape === 'ring') { ROWS = 9; COLS = 9; }
    else { ROWS = 10; COLS = 10; }

    boardValid = [];
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        let valid = true;
        if (shape === 'cross') {
          if (r >= 2 && r <= 6) valid = true;
          else if (c >= 2 && c <= 6) valid = true;
          else valid = false;
        } else if (shape === 'ring') {
          if (r >= 3 && r <= 5 && c >= 3 && c <= 5) valid = false;
          else valid = true;
        }
        boardValid.push(valid);
      }
    }
  }

  function initDraggableMascot() {
    const mascot = $('#guide-mascot');
    const dragHandle = $('#guide-character');
    if (!mascot || !dragHandle) return;

    let isDragging = false;
    let hasMoved = false;
    let startX, startY, initialLeft, initialTop;

    dragHandle.addEventListener('pointerdown', (e) => {
      if (e.target.closest('#guide-dismiss')) return;
      isDragging = true;
      hasMoved = false;
      const rect = mascot.getBoundingClientRect();
      mascot.style.right = 'auto'; mascot.style.bottom = 'auto';
      mascot.style.left = rect.left + 'px'; mascot.style.top = rect.top + 'px';
      startX = e.clientX; startY = e.clientY;
      initialLeft = rect.left; initialTop = rect.top;
      dragHandle.setPointerCapture(e.pointerId);
    });

    dragHandle.addEventListener('pointermove', (e) => {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) hasMoved = true;
      if (hasMoved) {
        mascot.style.left = `${initialLeft + dx}px`;
        mascot.style.top = `${initialTop + dy}px`;
      }
    });

    dragHandle.addEventListener('pointerup', (e) => {
      if (!isDragging) return;
      isDragging = false;
      dragHandle.releasePointerCapture(e.pointerId);
      if (hasMoved) setTimeout(() => { hasMoved = false; }, 50);
    });
    dragHandle.addEventListener('dragstart', (e) => e.preventDefault());
  }

  async function init() {
    try {
      const res = await fetch('/api/knowledge');
      if (!res.ok) throw new Error("HTTP error " + res.status);
      knowledge = await res.json();
    } catch (e) {
      console.error("知识加载失败:", e);
      if (boardEl) boardEl.innerHTML = '<p>知识数据加载失败，请刷新页面。</p>';
      return;
    }

    document.querySelectorAll('.difficulty-switch button').forEach(btn => {
      btn?.classList.toggle('active', btn.dataset.difficulty === difficulty);
      btn?.addEventListener('click', () => switchDifficulty(btn.dataset.difficulty));
    });

    $('#restart-button')?.addEventListener('click', () => {
        $('#end-dialog')?.close();
        prepareGame(false);
    });
    $('#start-button')?.addEventListener('click', startGame);
    $('#difficulty-cancel')?.addEventListener('click', closeDifficultyDialog);
    $('#difficulty-close')?.addEventListener('click', closeDifficultyDialog);
    $('#difficulty-confirm')?.addEventListener('click', confirmDifficultySwitch);
    $('#guide-character')?.addEventListener('click', (e) => { toggleGuideBubble(); });
    $('#guide-dismiss')?.addEventListener('click', dismissGuide);
    $('#summon-guide')?.addEventListener('click', () => {
        if($('#guide-mascot')) { $('#guide-mascot').hidden = false; $('#guide-mascot').style.display = ''; }
        if($('#summon-guide')) $('#summon-guide').style.display = 'none';
        guideSay("我回来啦！继续为你加油！");
    });
    $('#hint-button')?.addEventListener('click', hint);
    $('#shuffle-button')?.addEventListener('click', shuffle);
    $('#sound-button')?.addEventListener('click', toggleSound);

    let savedShape = localStorage.getItem('meridian-board-shape') || '10x10';
    if($('#board-size')) $('#board-size').value = savedShape;

    $('#board-size')?.addEventListener('change', (e) => {
      const shape = e.target.value;
      localStorage.setItem('meridian-board-shape', shape);
      setupBoardShape(shape);
      prepareGame(false);
    });

    setupBoardShape(savedShape);
    initDraggableMascot();
    if (window.matchMedia('(max-width: 600px)').matches) {
      $('#guide-bubble')?.classList.add('collapsed');
      $('#guide-character')?.setAttribute('aria-expanded', 'false');
    }
    prepareGame(false);
  }

  function prepareGame(showIntro) {
    clearInterval(timerId);
    timerId = null;
    const overlay = $('#game-overlay');
    if (overlay) overlay.classList.remove('hidden');

    if (!knowledge || !knowledge.length) return;

    pool = knowledge.slice(0, settings[difficulty].count);
    score = 0; combo = 0; collectedStars = 0; depositedStars = 0; mistakes = []; completed = new Set(); selected = null; busy = false; movesMade = 0;
    remaining = settings[difficulty].seconds; hintsLeft = settings[difficulty].hints || 0; shufflesLeft = settings[difficulty].shuffles || 0;
    resetStarPocket();
    buildBoard(); render(); updateHud();
    updateDifficultyControl();

    bgm.pause();
    bgm.currentTime = 0;
    clearTimeout(idleTimer);
  }

  function buildBoard() {
    board = new Array(ROWS * COLS).fill(null);
    for (let i = 0; i < ROWS * COLS; i++) {
      if (!boardValid[i]) continue;
      let tile, tries = 0;
      do {
        tile = randomTile();
        tries++;
      } while (tries < 30 && wouldMatch(i, tile.meridian));
      board[i] = tile;
    }
  }

  function wouldMatch(i, id) {
    const [r, c] = coords(i);
    return (c >= 2 && board[index(r, c - 1)]?.meridian === id && board[index(r, c - 2)]?.meridian === id) ||
           (r >= 2 && board[index(r - 1, c)]?.meridian === id && board[index(r - 2, c)]?.meridian === id);
  }

  function render() {
    if (!boardEl) return;
    // 核心修复：给棋盘加上 size-5 或 size-6 的类名，交由 CSS 控制字号
    boardEl.className = `board ${difficulty} size-${COLS}`;
    boardEl.innerHTML = '';

    // 动态设置网格布局列数
    boardEl.style.gridTemplateColumns = `repeat(${COLS}, 1fr)`;

    for (let i = 0; i < ROWS * COLS; i++) {
      if (!boardValid[i]) {
        const emptyDiv = document.createElement('div');
        emptyDiv.className = 'tile empty';
        boardEl.appendChild(emptyDiv);
        continue;
      }

      const tile = board[i];
      if (!tile) continue;

      const m = meridian(tile.meridian);
      const b = document.createElement('button');
      b.className='tile'; b.style.setProperty('--tile',m.color); b.dataset.index=i;
      b.setAttribute('role','gridcell');

      if (tile.special) {
        b.classList.add('has-special');
        b.setAttribute('aria-label', '特殊棋子');
        if (tile.special === 'row') b.innerHTML = `<span class="tile-shine"></span><span class="star">↔</span><span class="point">行消</span>`;
        else if (tile.special === 'col') b.innerHTML = `<span class="tile-shine"></span><span class="star">↕</span><span class="point">列消</span>`;
        else if (tile.special === 'time5') b.innerHTML = `<span class="tile-shine"></span><span class="star">⏱</span><span class="point">+5s</span>`;
        else if (tile.special === 'time10') b.innerHTML = `<span class="tile-shine"></span><span class="star">⏳</span><span class="point">+10s</span>`;
      } else {
        b.setAttribute('aria-label', difficulty==='hard'?`星点 ${tile.serial}`:`${tile.point}，${m.meridianName}`);
        const textLen = tile.point.length;
        const textClass = textLen >= 3 ? 'long-text' : '';
        const mood = ['happy', 'wink', 'wow'][i % 3];
        b.innerHTML=`<span class="tile-shine"></span><span class="tile-face ${mood}" aria-hidden="true"><i></i><i></i><b></b></span><span class="star">${difficulty==='hard'?tile.serial:'✦'}</span><span class="point ${textClass}">${tile.point}</span><span class="meridian">${m.shortName}</span>`;
      }

      if (tile._fallDist) {
        b.style.setProperty('--fall-y', `${tile._fallDist * 110}%`);
        b.classList.add('falling');
        delete tile._fallDist;
      }

      b.addEventListener('click',()=>choose(i,b));
      boardEl.appendChild(b);
    }
  }

  function createParticles(el) {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    for (let i = 0; i < 4; i++) {
      const particle = document.createElement('div');
      particle.classList.add('star-particle');
      const angle = Math.random() * Math.PI * 2;
      const distance = 25 + Math.random() * 45;
      const tx = Math.cos(angle) * distance;
      const ty = Math.sin(angle) * distance;
      particle.style.left = `${centerX}px`; particle.style.top = `${centerY}px`;
      particle.style.setProperty('--tx', `${tx}px`); particle.style.setProperty('--ty', `${ty}px`);
      particle.style.setProperty('--scale', 0.6 + Math.random() * 0.8);
      document.body.appendChild(particle);
      setTimeout(() => particle.remove(), 600);
    }
  }

  function resetStarPocket() {
    document.querySelectorAll('.flying-reward-star').forEach(star => star.remove());
    const pocket = $('#star-pocket');
    if (pocket) {
      pocket.classList.remove('receiving');
      pocket.innerHTML = '<span class="star-pocket-empty">成功连线后，星星会飞进这里</span>';
      pocket.setAttribute('aria-label', '还没有收集到星星');
    }
    if ($('#collected-star-count')) $('#collected-star-count').textContent = '0';
  }

  function depositRewardStar() {
    const pocket = $('#star-pocket');
    if (!pocket) return;
    depositedStars = Math.min(depositedStars + 1, collectedStars);
    pocket.querySelector('.star-pocket-empty')?.remove();

    if (depositedStars <= 10) {
      const star = document.createElement('i');
      star.className = 'collected-star';
      star.setAttribute('aria-hidden', 'true');
      star.textContent = '✦';
      pocket.appendChild(star);
    } else {
      let overflow = pocket.querySelector('.star-overflow-count');
      if (!overflow) {
        overflow = document.createElement('span');
        overflow.className = 'star-overflow-count';
        pocket.appendChild(overflow);
      }
      overflow.textContent = `还有 ${depositedStars - 10} 颗`;
    }

    if ($('#collected-star-count')) $('#collected-star-count').textContent = depositedStars;
    pocket.setAttribute('aria-label', `已经收集 ${depositedStars} 颗星星`);
    pocket.classList.remove('receiving');
    void pocket.offsetWidth;
    pocket.classList.add('receiving');
    setTimeout(() => pocket.classList.remove('receiving'), 380);
  }

  function collectRewardStar(sourceIndex) {
    collectedStars++;
    const pocket = $('#star-pocket');
    const source = document.querySelector(`[data-index="${sourceIndex}"]`) || boardEl;
    if (!pocket || !source || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      depositRewardStar();
      return;
    }

    const start = source.getBoundingClientRect();
    const target = pocket.getBoundingClientRect();
    const startX = start.left + start.width / 2;
    const startY = start.top + start.height / 2;
    const endX = target.left + target.width * (.2 + Math.random() * .6);
    const endY = target.top + target.height * .52;
    const dx = endX - startX;
    const dy = endY - startY;
    const flying = document.createElement('span');
    flying.className = 'flying-reward-star';
    flying.textContent = '✦';
    flying.setAttribute('aria-hidden', 'true');
    flying.style.setProperty('--start-x', `${startX}px`);
    flying.style.setProperty('--start-y', `${startY}px`);
    flying.style.setProperty('--fly-x', `${dx}px`);
    flying.style.setProperty('--fly-y', `${dy}px`);
    flying.style.setProperty('--mid-x', `${dx * .56}px`);
    flying.style.setProperty('--mid-y', `${dy * .5 - 70}px`);
    document.body.appendChild(flying);
    flying.addEventListener('animationend', () => {
      flying.remove();
      depositRewardStar();
    }, { once: true });
  }

  async function choose(i,el) {
    if (busy || !timerId) return;
    resetIdleTimer();

    if (board[i]?.special) {
      await triggerSpecial(i);
      return;
    }

    showKnowledge(board[i]);
    if (difficulty==='hard') { el.classList.add('revealed'); setTimeout(()=>el.classList.remove('revealed'),1300); }
    if (selected===null) { selected=i; el.classList.add('selected'); guideSay(`已选中“${board[i].point}”，再选一颗相邻的穴位星。`); return; }
    if (selected===i) { el.classList.remove('selected'); selected=null; return; }
    const previous=selected; document.querySelector(`[data-index="${previous}"]`)?.classList.remove('selected'); selected=null;
    if (!adjacent(previous,i)) { selected=i; el.classList.add('selected'); guideSay('两颗星要挨在一起才能交换哦。'); return; }
    await attemptSwap(previous,i);
  }

  async function triggerSpecial(i) {
    busy = true;
    const tile = board[i];
    const [r, c] = coords(i);

    if (tile.special === 'time5' || tile.special === 'time10') {
      const addTime = tile.special === 'time5' ? 5 : 10;
      remaining += addTime;
      updateHud();
      toast(`时间 +${addTime} 秒！`);
      guideSay(`太棒了！获得了 ${addTime} 秒的额外时间！`);
      collectRewardStar(i);

      const el = document.querySelector(`[data-index="${i}"]`);
      if(el) { el.classList.add('clearing'); createParticles(el); }
      board[i].special = null;
      await sleep(320);

      collapse(new Set([i])); render(); await sleep(360);
      await resolveMatches(); busy = false;

    } else if (tile.special === 'row' || tile.special === 'col') {
      let toClear = new Set();
      if (tile.special === 'row') {
        for (let k = 0; k < COLS; k++) { if (board[index(r, k)]) toClear.add(index(r, k)); }
      } else {
        for (let k = 0; k < ROWS; k++) { if (board[index(k, c)]) toClear.add(index(k, c)); }
      }

      toClear.forEach(idx => {
         const el = document.querySelector(`[data-index="${idx}"]`);
         if(el) { el.classList.add('clearing'); createParticles(el); }
      });
      const base = toClear.size;
      score += Math.round(base * settings[difficulty].multiplier);
      updateHud();
      toast(`星力连线 +${base}`);
      guideSay(`震撼的${tile.special === 'row' ? '横向' : '纵向'}星轨爆炸！`);
      collectRewardStar(i);

      await sleep(320);
      board[i].special = null;
      collapse(toClear); render(); await sleep(360);
      await resolveMatches(); busy = false;
    }
  }

  async function attemptSwap(a,b) {
    busy=true; movesMade++; [board[a],board[b]]=[board[b],board[a]]; render(); await sleep(180);
    if (!findMatches().indices.size) {
        [board[a],board[b]]=[board[b],board[a]]; render(); combo=0; mistakes.push(board[a]);
        const message=difficulty==='hard'?'这次没有连成同一经络，再观察一下吧。':`${board[a].point}属于${meridian(board[a].meridian).meridianName}，换一组试试。`;
        toast(difficulty==='hard'?'未形成同经络组合':`${board[a].point}属于${meridian(board[a].meridian).meridianName}`);
        guideSay(message); busy=false; return;
    }
    await resolveMatches(); busy=false;
  }

  function findMatches() {
    let horizontal = [];
    let vertical = [];

    for (let r = 0; r < ROWS; r++) {
      let c = 0;
      while (c < COLS) {
        if (!board[index(r, c)]) { c++; continue; }
        let start = c;
        let m = board[index(r, c)].meridian;
        while (c < COLS && board[index(r, c)] && board[index(r, c)].meridian === m) { c++; }
        if (c - start >= 3) {
          let group = [];
          for (let x = start; x < c; x++) group.push(index(r, x));
          horizontal.push(group);
        }
      }
    }

    for (let c = 0; c < COLS; c++) {
      let r = 0;
      while (r < ROWS) {
        if (!board[index(r, c)]) { r++; continue; }
        let start = r;
        let m = board[index(r, c)].meridian;
        while (r < ROWS && board[index(r, c)] && board[index(r, c)].meridian === m) { r++; }
        if (r - start >= 3) {
          let group = [];
          for (let y = start; y < r; y++) group.push(index(y, c));
          vertical.push(group);
        }
      }
    }

    let indices = new Set();
    let specials = [];

    if (difficulty === 'easy') {
      let hMap = new Map();
      horizontal.forEach(g => g.forEach(i => hMap.set(i, g)));
      let vMap = new Map();
      vertical.forEach(g => g.forEach(i => vMap.set(i, g)));
      let processed = new Set();

      hMap.forEach((hGroup, i) => {
        if (vMap.has(i)) {
          indices.add(i);
          specials.push({ index: i, type: 'time5' });
          hGroup.forEach(idx => indices.add(idx));
          let vGroup = vMap.get(i);
          vGroup.forEach(idx => indices.add(idx));
          processed.add(i);
        }
      });

      horizontal.forEach(group => {
        if (!group.some(i => processed.has(i))) {
          group.forEach(i => indices.add(i));
          if (group.length === 4) specials.push({ index: group[1], type: Math.random() > 0.5 ? 'row' : 'col' });
          else if (group.length >= 5) specials.push({ index: group[2], type: 'time10' });
        }
      });

      vertical.forEach(group => {
        if (!group.some(i => processed.has(i))) {
          group.forEach(i => indices.add(i));
          if (group.length === 4) specials.push({ index: group[1], type: Math.random() > 0.5 ? 'row' : 'col' });
          else if (group.length >= 5) specials.push({ index: group[2], type: 'time10' });
        }
      });
    } else {
      horizontal.forEach(group => group.forEach(i => indices.add(i)));
      vertical.forEach(group => group.forEach(i => indices.add(i)));
    }

    return { indices, specials };
  }

  async function resolveMatches() {
    let result = findMatches();
    while(result.indices.size > 0){
      combo++;
      result.specials.forEach(s => result.indices.delete(s.index));

      const rewardSource = result.indices.values().next().value;
      if (rewardSource !== undefined) collectRewardStar(rewardSource);

      result.indices.forEach(i=>{
        const el = document.querySelector(`[data-index="${i}"]`);
        if(el) { el.classList.add('clearing'); createParticles(el); }
        if (board[i]) completed.add(board[i].meridian);
      });
      const base=result.indices.size+(combo-1);
      score+=Math.round(base*settings[difficulty].multiplier);
      updateHud();
      toast(combo>1?`连击 × ${Math.min(combo,5)}！`:`星光连线 +${result.indices.size}`);

      if (Math.random() < 0.4) guideSay(successTips[Math.floor(Math.random() * successTips.length)]);
      else guideSay(combo>1?`漂亮！已经连续消除 ${combo} 次啦！`:'连线成功！同一经络的穴位会互相呼应。');

      await sleep(320);
      result.specials.forEach(s => { if (board[s.index]) board[s.index].special = s.type; });
      collapse(result.indices);
      render();
      await sleep(360);
      result=findMatches();
    }
    combo=0;
    if(!findMove()){shuffle(true);toast('星河重新排列');}
  }

  function collapse(matches) {
    for (let c = 0; c < COLS; c++) {
      let kept = [];
      for (let r = ROWS - 1; r >= 0; r--) {
        const i = index(r, c);
        if (!boardValid[i]) continue;
        if (!matches.has(i) || board[i]?.special) {
          kept.push({ tile: board[i], originalRow: r });
        }
      }

      let k = 0;
      for (let r = ROWS - 1; r >= 0; r--) {
        const i = index(r, c);
        if (!boardValid[i]) { board[i] = null; continue; }

        if (k < kept.length) {
          const item = kept[k];
          board[i] = item.tile;
          const dropDist = item.originalRow - r;
          if (dropDist !== 0) board[i]._fallDist = dropDist;
          k++;
        } else {
          board[i] = randomTile();
          board[i]._fallDist = -(Math.random() * 5 + 5);
        }
      }
    }
  }

  function hasMatchAt(r, c) {
    const m = board[index(r,c)]?.meridian;
    if (!m) return false;

    let count = 1;
    for(let i=c-1; i>=0 && board[index(r,i)]?.meridian===m; i--) count++;
    for(let i=c+1; i<COLS && board[index(r,i)]?.meridian===m; i++) count++;
    if (count >= 3) return true;

    count = 1;
    for(let i=r-1; i>=0 && board[index(i,c)]?.meridian===m; i--) count++;
    for(let i=r+1; i<ROWS && board[index(i,c)]?.meridian===m; i++) count++;
    if (count >= 3) return true;
    return false;
  }

  function findMove() {
    for(let i=0; i<ROWS*COLS; i++){
        if (!board[i]) continue;
        const [r,c]=coords(i);
        for(const j of [c<COLS-1?i+1:-1, r<ROWS-1?i+COLS:-1]){
            if(j<0 || !board[j])continue;
            [board[i],board[j]]=[board[j],board[i]];
            const [r2,c2] = coords(j);
            const ok = hasMatchAt(r, c) || hasMatchAt(r2, c2);
            [board[i],board[j]]=[board[j],board[i]];
            if(ok)return[i,j];
        }
    }
    return null;
  }

  function hint() {
    if(!timerId||busy||hintsLeft<=0)return;
    resetIdleTimer();
    const move=findMove();
    if(move){
      hintsLeft--;
      move.forEach(i=>document.querySelector(`[data-index="${i}"]`)?.classList.add('hint'));
      setTimeout(()=>document.querySelectorAll('.hint').forEach(e=>e.classList.remove('hint')),2200);
      updateHud();
      guideSay("看，这两颗星可以交换！");
    }
  }

  function shuffle(auto=false) {
    if(!timerId||busy)return;
    resetIdleTimer();
    if(difficulty==='hard'&&!auto){if(shufflesLeft<=0)return;shufflesLeft--;}

    let validTiles = [];
    for(let i=0; i<ROWS*COLS; i++) {
      if (boardValid[i]) validTiles.push(board[i]);
    }
    validTiles.sort(()=>Math.random()-.5);

    let k = 0;
    for(let i=0; i<ROWS*COLS; i++) {
      if (boardValid[i]) {
        board[i] = validTiles[k++];
        delete board[i]._fallDist;
      }
    }

    if(findMatches().indices.size||!findMove()) buildBoard();
    render();updateHud();
  }

  function startGame() {
    const overlay = $('#game-overlay');
    if (overlay) overlay.classList.add('hidden');

    if (isSoundOn) bgm.play().catch(e => console.log("音频播放被阻止或未找到文件:", e));

    startedAt=Date.now();
    timerId=setInterval(()=>{
      remaining--;
      updateHud();
      if(remaining<=0)finish();
    },1000);

    resetIdleTimer();
  }

  async function finish() {
    clearInterval(timerId);timerId=null;
    clearTimeout(idleTimer);
    bgm.pause();

    const record={difficulty,score,completedMeridians:[...completed],mistakes:mistakes.map(x=>x.point),hintsUsed:(settings[difficulty].hints||0)-hintsLeft,duration:Math.round((Date.now()-startedAt)/1000)};
    localStorage.setItem(`meridian-best-${difficulty}`,Math.max(score,Number(localStorage.getItem(`meridian-best-${difficulty}`)||0)));
    try{await fetch('/api/records',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(record)});}catch(e){}
    if($('#final-score')) $('#final-score').textContent=score;
    if($('#mastered-summary')) $('#mastered-summary').textContent=`本局连线 ${completed.size} 条经络，收集 ${collectedStars} 颗星：${[...completed].map(id=>meridian(id)?.shortName || '').join('、')||'继续加油'}`;
    if($('#mistake-review')) $('#mistake-review').innerHTML=[...new Set(mistakes.map(x=>x.point))].slice(0,5).map(name=>{const x=mistakes.find(m=>m.point===name),m=meridian(x.meridian);return`<p>错题回顾：${name} · ${m?.meridianName || ''} · ${m?.bodyRegion || ''}</p>`}).join('');
    $('#end-dialog')?.showModal();
    updateHud();
  }

  function updateHud() {
    if($('#score')) $('#score').textContent=score;
    if($('#timer')) $('#timer').textContent=`${String(Math.floor(remaining/60)).padStart(2,'0')}:${String(remaining%60).padStart(2,'0')}`;
    if($('#best-score')) $('#best-score').textContent=localStorage.getItem(`meridian-best-${difficulty}`)||0;
    const next=milestones.find(x=>x>score)||1000;
    if($('#progress-label')) $('#progress-label').textContent=score>=1000?'全部里程碑达成':`下一里程碑 ${next}`;
    if($('#progress-bar')) $('#progress-bar').style.width=`${Math.min(100,(score/(next||1))*100)}%`;
    if($('#hint-button')) $('#hint-button').style.display=difficulty==='hard'?'none':'';
    if($('#hint-count')) $('#hint-count').textContent=`${hintsLeft} 次`;
    if($('#shuffle-button')) $('#shuffle-button').innerHTML=difficulty==='hard'?`<span>↻</span> 洗牌 <small>${shufflesLeft} 次</small>`:'<span>↻</span> 重新排列';
  }

  function showKnowledge(tile) {
    const m=meridian(tile.meridian);
    if (!m) return;
    if($('#knowledge-empty')) $('#knowledge-empty').hidden=true;
    if($('#knowledge-card')) $('#knowledge-card').hidden=false;
    if($('#knowledge-mark')) $('#knowledge-mark').style.background=m.color;
    if($('#knowledge-point')) $('#knowledge-point').textContent=`穴位 · ${tile.point}`;
    if($('#knowledge-name')) $('#knowledge-name').textContent=m.meridianName;
    if($('#knowledge-route')) $('#knowledge-route').textContent=m.routeSummary;
    if($('#knowledge-region')) $('#knowledge-region').textContent=m.bodyRegion;
  }

  function switchDifficulty(next) {
    if (next===difficulty) return;
    if (!timerId || movesMade === 0) { applyDifficulty(next); return; }
    pendingDifficulty=next;
    const names={easy:'新星 · 颜色识经',normal:'巡星 · 文字辨脉',hard:'星官 · 记忆挑战'};
    if($('#difficulty-from')) $('#difficulty-from').textContent=names[difficulty];
    if($('#difficulty-to')) $('#difficulty-to').textContent=names[next];
    $('#difficulty-dialog')?.showModal();
  }

  function closeDifficultyDialog() { pendingDifficulty=null; $('#difficulty-dialog')?.close(); }
  function confirmDifficultySwitch() { if(!pendingDifficulty)return; const next=pendingDifficulty; pendingDifficulty=null; $('#difficulty-dialog')?.close(); applyDifficulty(next); }

  function applyDifficulty(next) {
    difficulty=next;
    history.replaceState(null,'',`/meridian-match?difficulty=${next}`);
    prepareGame(false);
    const tips={easy:'新星等级会显示颜色、经络和穴位，放心大胆地观察吧！',normal:'巡星等级隐藏了颜色，要多留意穴位名称哦。',hard:'星官等级只显示编号，点击星珠才能短暂看到穴位。'};
    guideSay(tips[next]);
  }

  function updateDifficultyControl() {
    const summaries={easy:'6 条经络 · 颜色辅助 · 3 次提示',normal:'10 条经络 · 文字判断 · 2 次提示',hard:'14 条经络 · 纯记忆 · 1 次洗牌'};
    const order={easy:0,normal:1,hard:2};
    document.querySelectorAll('.difficulty-switch button').forEach(b=>b.classList.toggle('active',b.dataset.difficulty===difficulty));
    $('.difficulty-switch')?.style.setProperty('--active-index',order[difficulty]);
    if($('#difficulty-summary')) $('#difficulty-summary').textContent=summaries[difficulty];
  }

  function toast(text) { const e=$('#toast'); if(!e) return; e.textContent=text; e.classList.add('show'); setTimeout(()=>e.classList.remove('show'),1500); }

  function toggleSound() {
    const b = $('#sound-button');
    isSoundOn = !isSoundOn;
    if(b) { b.setAttribute('aria-pressed', String(isSoundOn)); b.textContent = `♪ 音效：${isSoundOn ? '开' : '关'}`; }

    if (isSoundOn) { if (timerId) bgm.play().catch(e => console.log(e)); } else { bgm.pause(); }
  }

  function guideSay(message) {
    const guide=$('#guide-mascot');
    if(!guide||guide.hidden)return;
    if($('#guide-message')) $('#guide-message').textContent=message;
    $('#guide-bubble')?.classList.remove('collapsed');
    $('#guide-character')?.setAttribute('aria-expanded','true');
  }

  function toggleGuideBubble() {
    const bubble=$('#guide-bubble');
    if(!bubble) return;
    const collapsed=bubble.classList.toggle('collapsed');
    $('#guide-character')?.setAttribute('aria-expanded',String(!collapsed));
  }

  function dismissGuide() {
    if($('#guide-mascot')) { $('#guide-mascot').hidden=true; $('#guide-mascot').style.display='none'; }
    if($('#summon-guide')) $('#summon-guide').style.display='flex';
  }

  init();
})();
