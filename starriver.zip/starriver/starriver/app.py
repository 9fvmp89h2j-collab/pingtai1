# -*- coding: utf-8 -*-
"""经络星河 Flask 应用与 API。"""

from __future__ import annotations

import json
import mimetypes
import os
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request, url_for


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
RECORDS_FILE = DATA_DIR / "records.json"

# Windows does not always register WebP in its MIME database. Explicitly add it
# so animated guide assets are decoded by browsers instead of downloaded.
mimetypes.add_type("image/webp", ".webp")


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(SECRET_KEY=os.environ.get("SECRET_KEY", "meridian-star-river-dev"))
    if test_config:
        app.config.update(test_config)

    @app.get("/")
    def home():
        return redirect(url_for("meridian_match", difficulty="easy"))

    @app.get("/jingluo")
    def jingluo():
        # The explicit return button uses ?view=stars, avoiding a redirect loop.
        if request.args.get("view") != "stars":
            return redirect(url_for("meridian_match", difficulty="easy"))
        return render_template("stars.html", meridians=load_knowledge())

    @app.get("/meridian-match")
    def meridian_match():
        difficulty = request.args.get("difficulty", "easy")
        if difficulty not in {"easy", "normal", "hard"}:
            difficulty = "easy"
        return render_template("game.html", difficulty=difficulty)

    @app.get("/api/knowledge")
    def knowledge_api():
        return jsonify(load_knowledge())

    @app.route("/api/records", methods=["GET", "POST"])
    def records_api():
        if request.method == "GET":
            return jsonify(load_records())

        payload = request.get_json(silent=True) or {}
        required = {"difficulty", "score", "completedMeridians", "mistakes", "hintsUsed", "duration"}
        if not required.issubset(payload):
            return jsonify({"error": "记录字段不完整"}), 400
        if payload["difficulty"] not in {"easy", "normal", "hard"}:
            return jsonify({"error": "难度无效"}), 400

        record = {key: payload[key] for key in required}
        record["createdAt"] = datetime.now(timezone.utc).isoformat()
        records = load_records()
        records.append(record)
        save_records(records[-200:])
        return jsonify(record), 201

    return app


def load_knowledge() -> list[dict]:
    # 使用 utf-8-sig 可以防止 Windows 记事本保存时带的 BOM 头导致报错
    with (DATA_DIR / "knowledge.json").open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def load_records() -> list[dict]:
    if not RECORDS_FILE.exists():
        return []
    try:
        with RECORDS_FILE.open("r", encoding="utf-8-sig") as handle:
            return json.load(handle)
    except (json.JSONDecodeError, OSError):
        return []


def save_records(records: list[dict]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp_file = RECORDS_FILE.with_suffix(".tmp")
    with temp_file.open("w", encoding="utf-8") as handle:
        json.dump(records, handle, ensure_ascii=False, indent=2)
    temp_file.replace(RECORDS_FILE)


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)