# -*- coding: utf-8 -*-
"""PyCharm 统一运行入口。

在 PyCharm 中打开项目后，直接运行本文件即可启动经络星河。
"""

from app import app

def main() -> None:
    app.run(host="127.0.0.1", port=5000, debug=True)


if __name__ == "__main__":
    main()

