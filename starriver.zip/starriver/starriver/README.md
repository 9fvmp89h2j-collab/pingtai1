# 经络星河 · 经络消消看

依据《经络星河-消消乐改版方案与素材分工》实现的 Python Web 游戏。后端使用 Flask，前端为原生 HTML/CSS/JavaScript，无需构建工具。

## 使用 PyCharm 打开与运行

1. 在 PyCharm 选择“打开”，选中本仓库根目录。
2. 首次打开时，选择 Python 3.10 或更高版本作为项目解释器；推荐 Python 3.12。
3. 在 PyCharm 终端执行 `pip install -r requirements.txt`。
4. 右上角选择“运行经络星河”，点击绿色运行按钮。也可以右键 `main.py` 选择“运行”。

项目统一使用 UTF-8 编码，运行入口为 `main.py`，测试入口为“运行全部测试”。

## 命令行运行

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python main.py
```

浏览器打开 `http://127.0.0.1:5000/jingluo`。该入口会直接进入初级游戏；游戏内“查看经络星河”可打开知识档案。

## 已实现

- `/jingluo` 一次跳转到 `/meridian-match?difficulty=easy`，显式返回不会循环跳转
- 10×10 棋盘、相邻交换、横纵三连、连锁下落、无可用交换时重排
- 初级 6 条经络（颜色、经络、穴位）、中级 10 条（无颜色）、高级 14 条（编号、点击揭示）
- 三档独立最高分、提示/洗牌次数、限时、难度倍率、里程碑进度
- 14 条经络知识卡、局末掌握经络与错题回顾
- 学习报告写入 `data/records.json`，浏览器最高分保存在 localStorage
- 响应式桌面/移动布局、键盘可聚焦棋子、减少动态效果兼容基础结构

## 测试

```powershell
pytest -q
```

> 医学内容来自需求文档，正式发布前仍需按方案要求由中医专业人员逐条审校并补充来源、审校人和日期。
